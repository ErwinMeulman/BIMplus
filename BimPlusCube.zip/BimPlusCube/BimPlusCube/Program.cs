﻿using BimPlus.LightCaseClient;
using BimPlus.Sdk.Data.Authentication;
using BimPlus.Sdk.Data.DbCore;
using BimPlus.Sdk.Data.DbCore.Building;
using BimPlus.Sdk.Data.DbCore.Structure;
using BimPlus.Sdk.Data.Geometry;
using BimPlus.Sdk.Data.TenantDto;
using BimPlus.Sdk.Data.UserAdministration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BimPlusDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bim+ Cube Demo");
            Console.WriteLine();
            Console.Write("Login: ");
            String user = Console.ReadLine();
            
            Console.Write("Password: ");
            String password = Console.ReadLine();

            Console.WriteLine();

            var config = GenericProxies.CreateDefaultConfiguration();

            // Create authentication request, providing some user information 
            AuthenticationAuthorizeRequest request = new AuthenticationAuthorizeRequest();
            request.UserId = user;
            request.Password = password;
            request.ClientId = Guid.NewGuid();
            request.ApplicationId = new Guid("FE9BE983-DF2C-4414-AD3F-B9A1EF6AB29A");

            String host = "https://api.bimplus.net";
            
            try
            {
                String serviceUrl = host + "/v2/authorize";
                AuthenticationAuthorizeResponse response = null;

                // Post the authorize request
                response = GenericProxies.RestPost<AuthenticationAuthorizeResponse, AuthenticationAuthorizeRequest>(serviceUrl, request);
                if (response != null)
                {
                    config.AuthorizationAccessToken = new Guid(response.AccessToken); // Store the returned access token
                    config.AuthorizationTokenType = response.TokenType;
                }

                Console.WriteLine(String.Format("Hello {0}, welcome to bim+", user));

                // Get all teams of the user
                String serviceUrlTeams = host + "/v2/teams";
                List<DtoClientTeam> teams = GenericProxies.RestGet<List<DtoClientTeam>>(serviceUrlTeams, config);

                Console.WriteLine();
                Console.WriteLine(String.Format("You are member of {0} teams:", teams.Count));

                int index = 0;
                foreach (var team in teams)
                {
                    Console.WriteLine(String.Format(" ({0}) {1}", index, team.Name));
                    index++;
                }

                // Choose current team
                Console.Write("Please choose your team:");
                int teamIndex = 0;
                int.TryParse(Console.ReadLine(), out teamIndex);

                String teamSlug = teams[teamIndex].Slug;


                Console.WriteLine();
                Console.WriteLine("Please enter name for the new project:");
                String name = Console.ReadLine();

                // Create a new project
                var dtoProject = GenericProxies.RestPost<DtoShortProject, DtoShortProject>(host + "/v2/" + teamSlug + "/projects/", new DtoShortProject(){Name = name}, config);

                // Create a new model for the project
                var dtoDivision = GenericProxies.RestPost<DtoDivision, DtoDivision>(host + "/v2/" + teamSlug + "/projects/" + dtoProject.Id.ToString() + "/divisions", new DtoDivision(){Name = "MyModel"}, config);

                // Create a topology division node
                var topoDivNode = new TopologyDivision()
                {
                    Name = dtoDivision.Name,
                    Id = Guid.NewGuid(),
                    Parent = dtoProject.Id,
                    Division = dtoDivision.Id
                };

                // Create a topology noew
                var topoNode = new Topology()
                {
                    Name = "TopologyNode",
                    Id = Guid.NewGuid(),
                    Division = dtoDivision.Id
                };

                topoDivNode.AddChildren(topoNode);

                // Create the cube object
                var cube = new GeometryObject()
                {
                    Name = "Cube",
                    Description = "My cube",
                    Id = Guid.NewGuid(),
                    Parent = topoNode.Id,
                    Division = dtoDivision.Id
                };

                topoNode.AddChildren(cube);

                // Create the actual cube mesh
                cube.Mesh = new DbGeometry()
                {
                    Vertices = new List<double>()
                    {
                        0.0,0.0,0.0,5000.0,0.0,0.0,5000.0,5000.0,0.0,0.0,5000.0,0.0,0.0,0.0,5000.0,5000.0,0.0,5000.0,5000.0,5000.0,5000.0,0.0,5000.0,5000.0
                    },
                    Faces = new List<ushort>()
                    {
                        4,0,1,2,3,4,4,5,6,7,4,0,1,5,4,4,1,2,6,5,4,6,2,3,7,4,3,7,4,0
                    }
                };

                String serviceUrlObjects = host + "/v2/" + teamSlug + "/objects/";

                // Post the object tree
                GenericProxies.RestPost<DtObject, DtObject>(serviceUrlObjects, topoDivNode, config);

                // Receive the cube object and its geometry for validation
                // /properties/{flag} where flag is an integer interpreted as bitfield
                // Bit 3 is set to transfer also geometry data
                var dto = GenericProxies.RestGet<GeometryObject>(serviceUrlObjects + cube.Id.ToString() + "/properties/4", config);

                DbGeometry mesh = dto.Mesh;

                // Print vertices and faces
                Console.WriteLine("Cube geometry:");
                Console.WriteLine(String.Format("Vertices: {0}", String.Join(", ", mesh.Vertices)));
                Console.WriteLine(String.Format("Faces: {0}", String.Join(", ", mesh.Faces)));

                Console.ReadLine();
            }
            catch (WebException ex)
            {
                Console.WriteLine(ex.Message);
                Console.Write("Press Enter to exit");
                Console.ReadLine();
                return;
            }

        }
    }
}
