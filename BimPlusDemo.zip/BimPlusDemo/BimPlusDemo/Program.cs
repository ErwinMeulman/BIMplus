﻿using BimPlus.LightCaseClient;
using BimPlus.Sdk.Data.Authentication;
using BimPlus.Sdk.Data.TenantDto;
using BimPlus.Sdk.Data.UserAdministration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Project = BimPlus.Sdk.Data.DbCore.Structure.Project;

namespace BimPlusDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bim+ REST api demo");
            Console.WriteLine();
            Console.Write("Login: ");
            String user = Console.ReadLine();
            Console.Write("Password: ");
            String password = Console.ReadLine();

            Console.WriteLine();

            var config = GenericProxies.CreateDefaultConfiguration();

            // Create authentication request, providing some user information 
            AuthenticationAuthorizeRequest request = new AuthenticationAuthorizeRequest();
            request.UserId = user;
            request.Password = password;
            request.ClientId = Guid.NewGuid();
            request.ApplicationId = new Guid("FE9BE983-DF2C-4414-AD3F-B9A1EF6AB29A");

            String host = "https://api-stage.bimplus.net";

            String serviceUrl = host + "/v2/authorize";
            AuthenticationAuthorizeResponse response = null;

            // Post the authorize request
            try
            {
                response = GenericProxies.RestPost<AuthenticationAuthorizeResponse, AuthenticationAuthorizeRequest>(serviceUrl, request);
                if (response != null)
                {
                    config.AuthorizationAccessToken = new Guid(response.AccessToken); // Store the returned access token
                    config.AuthorizationTokenType = response.TokenType;
                }
            }
            catch (WebException ex)
            {
                // Authorization failed
                Console.WriteLine(ex.Message);
                Console.Write("Press Enter to exit");
                Console.ReadLine();
                return;
            }

            Console.WriteLine(String.Format("Hello {0}, welcome to bim+",user));

            // Get all teams of the user
            String serviceUrlTeams = host + "/v2/teams";
            List<DtoClientTeam> teams;
            try
            {
                teams = GenericProxies.RestGet<List<DtoClientTeam>>(serviceUrlTeams, config);
            }
            catch (WebException ex)
            {
                Console.WriteLine(ex.Message);
                Console.Write("Press Enter to exit");
                Console.ReadLine();
                return;
            }

            Console.WriteLine();
            Console.WriteLine(String.Format("You are member of {0} teams:", teams.Count));
            int index = 0;
            foreach (var team in teams)
            {
                Console.WriteLine(String.Format(" ({0}) {1}",index,team.Name));
                index++;
            }

            // Choose current team
            Console.Write("Please choose your team index:");
            int teamIndex = 0;
            int.TryParse(Console.ReadLine(),out teamIndex);

            String teamSlug = teams[teamIndex].Slug;

            // Get all projects of the current team which are visible to the user
            List<DtoShortProject> dtoProjects = null;

            String serviceUrlProjects = host + "/v2/" + teamSlug + "/projects/";
            

            Console.Write("Enter a project name which we are going to create: ");
            String projectName = Console.ReadLine();

            var myProject = new DtoShortProject()
            {
                Name = projectName,
                ShortDescription = "Your awesome project"
            };

            var dtoProject = GenericProxies.RestPost<DtoShortProject, DtoShortProject>(serviceUrlProjects, myProject, config);
            

            //Console.ReadLine();

            Console.Write("Enter a model name which we are going to create: ");

            String serviceUrlModels = host + "/v2/" + teamSlug + "/projects/" + dtoProject.Id + "/divisions/";

            String modelName = Console.ReadLine();

            var myModel = new DtoDivision()
            {
                Name = modelName
            };

            var dtoModel = GenericProxies.RestPost<DtoDivision, DtoDivision>(serviceUrlModels, myModel, config);

            Console.WriteLine("Now please check the portal(https://www-stage.bimplus.net) whether the created project & model are there");

            String serviceUrlImport = host + "/v2/" + teamSlug + "/projects/" + dtoProject.Id + "/model/" + dtoModel.Id + "/importasync/";
           
            
            var myByteArray = Properties.Resources.Ballo;

            //byte[] myByteArray = File.ReadAllBytes(@"C:\Jay\BimPlusDemoForScia\BimPlusDemo\Resources\Ballo.ifc");



            HttpContent bytesContent = new ByteArrayContent(myByteArray);
            using (var client = new HttpClient())
            using (var formData = new MultipartFormDataContent())
            {
                client.DefaultRequestHeaders.Add("Authorization", config.AuthorizationTokenType + " " + config.AuthorizationAccessToken.ToString());
                //client.DefaultRequestHeaders.Add("Accept", "multipart/form-data");

                // the extension(ifc or skp) is important. Otherwise it won't work
                formData.Add(bytesContent, "Ballo.ifc", "Ballo.ifc");

                var myResponse = client.PostAsync(serviceUrlImport, formData).Result;

                Console.WriteLine(myResponse.ToString());

                Console.ReadLine();
            }

            
        }
    }
}
